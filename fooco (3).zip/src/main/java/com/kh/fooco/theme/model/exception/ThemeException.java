package com.kh.fooco.theme.model.exception;

public class ThemeException extends RuntimeException{
	public ThemeException(String msg) {
		super(msg);
	}
	
}
