package com.kh.fooco.membership.model.exception;

public class MemberShipException extends RuntimeException{
	public MemberShipException(String msg) {
		super(msg);
	}
}
