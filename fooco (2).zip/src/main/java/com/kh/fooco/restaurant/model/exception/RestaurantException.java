package com.kh.fooco.restaurant.model.exception;

public class RestaurantException {

}
