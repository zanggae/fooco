package com.kh.fooco.restaurant.model.service;

public interface RestaurantService {

}
