package com.kh.fooco.restaurant.model.dao;

public class RestaurantDao {

}
