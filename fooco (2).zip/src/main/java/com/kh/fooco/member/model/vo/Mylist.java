package com.kh.fooco.member.model.vo;

public class Mylist {

}
