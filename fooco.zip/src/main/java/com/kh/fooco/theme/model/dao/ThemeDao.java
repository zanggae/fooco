package com.kh.fooco.theme.model.dao;

public class ThemeDao {

}
