package com.kh.fooco.theme.model.service;

public class ThemeServiceImpl implements ThemeService{

}
