package com.kh.fooco.theme.model.vo;

public class Theme {

}
