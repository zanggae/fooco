package com.kh.fooco.theme.model.service;

public interface ThemeService {

}
