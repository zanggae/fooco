package com.kh.fooco.membership.model.exception;

public class MemberShipException {

}
