package com.kh.fooco.member.model.exception;

public class MemberException extends RuntimeException{
	public MemberException(String msg) {
		super(msg);
	}
}
