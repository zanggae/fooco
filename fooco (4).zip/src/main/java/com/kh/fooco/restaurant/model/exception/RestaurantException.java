package com.kh.fooco.restaurant.model.exception;

public class RestaurantException extends RuntimeException {

	public RestaurantException(String msg) {
		super(msg);
	}
	
}
